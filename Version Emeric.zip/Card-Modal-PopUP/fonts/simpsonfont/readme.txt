OTF: Simpsonfont
Dennis Ludlow 2017 all rights reserved
by Sharkshock 
dennis@sharkshock.net

Cowabunga font lovers! After 10+ years this old classic gets a serious facelift. Changes were made to smoothen out the curves and make them appear more "ink" like. This update features 
completely redrawn glyphs, kerning, basic/extended latin, European accents, and Cyrillic characters. Use Simpsonfont in a poster, game, or kid's book. The demo version features
basic latin, numbers, limited punctuation, and limited kerning.

Complete regular version is available with purchase of commercial license or $25 payment via PayPal. Please note that this $25 is for PERSONAL use only and does not constitute a 
commercial license.

This font like my others are free for personal use only as long as this readme file stays intact. For commercial use please contact me at dennis@sharkshock.net to discuss an end user license agreement. You can also visit www.sharkshock.net/license for more info and terms. I also design custom 
fonts for companies, logos, and many other things. If you'd like to leave me a PayPal donation you can use my email address above. Your generosity will be most appreciated! 

Thank you for your support!

visit www.sharkshock.net for more and take a bite out of BORING design!

tags: children, kids, sans, sans serif, cartoon, sloppy, handwriting, handwritten, Simpsons, abstract, Homer, publishing, project, scrapbook, sharkshock, latin, Russian, Ukranian,
childrens, child, book, display, logo, show, tv, movies, media



