var allDiv = document.querySelectorAll("div");
var popUp = document.getElementById("popUp");
var createAudio = popUp.appendChild(document.createElement("audio"));
var createP = popUp.appendChild(document.createElement("p"));
var crossElt = document.getElementById("cross");
function parcour() {
  for (i = 0; i < allDiv.length; i++) {
    if (allDiv[i].classList == "overflow") {
      allDiv[i].addEventListener("click", function() {
        popUp.style.display = "block";
        popUp.style.width = "50%";
        popUp.style.height = "auto";
        var selectedId = this.getAttribute("id");
        createP.innerHTML = selectedId;
        createAudio.setAttribute("class", "audio");
        createAudio.setAttribute("controls", "true");
        createAudio.setAttribute("src", "./songs/" + selectedId + ".mp3");
      });
    }
  }
}
function closeCross() {
  crossElt.addEventListener("click", function() {
    popUp.style.display = "none";
    createAudio.setAttribute("src", " ");
  });
}
window.addEventListener("mouseup", function(event) {
  if (event.target != popUp && event.target.parentNode != popUp) {
    popUp.style.display = "none";
    createAudio.setAttribute("src", " ");
  }
});
parcour();
closeCross();
